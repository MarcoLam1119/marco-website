// Payment Calculator JS
let names = ['Marco', 'Eunice'];
let items = [];
let currentStep = 1;

document.addEventListener('DOMContentLoaded', () => {
  // Load from localStorage
  if (localStorage.getItem('paymentNames')) {
    names = JSON.parse(localStorage.getItem('paymentNames'));
  }
  if (localStorage.getItem('paymentItems')) {
    items = JSON.parse(localStorage.getItem('paymentItems'));
    // Clean items based on current names
    items.forEach(item => {
      if (item.utilized) item.utilized = item.utilized.filter(u => names.includes(u));
      if (!names.includes(item.payer)) item.payer = names[0] || '';
    });
    saveData(); // Save cleaned data
  }
  renderNames();
  renderItems();
});

function saveData() {
  localStorage.setItem('paymentNames', JSON.stringify(names));
  localStorage.setItem('paymentItems', JSON.stringify(items));
}

function clearData() {
  names = ['Marco', 'Eunice'];
  items = [];
  currentStep = 1;
  localStorage.removeItem('paymentNames');
  localStorage.removeItem('paymentItems');
  showStep(1);
  renderNames();
  renderItems();
}

function renderNames() {
  const list = document.getElementById('namesList');
  list.innerHTML = '';
  names.forEach((name, i) => {
    list.innerHTML += `
      <div style="display: flex; gap: 8px; margin-bottom: 8px;">
        <input value="${name}" onchange="updateName(${i}, this.value)" />
        <button onclick="removeName(${i})">❌</button>
      </div>
    `;
  });
}

function updateName(i, val) {
  names[i] = val;
  saveData();
}

function removeName(i) {
  names.splice(i, 1);
  saveData();
  renderNames();
}

function addName() {
  names.push('New Person');
  saveData();
  renderNames();
}

function renderItems() {
  const list = document.getElementById('itemsList');
  list.innerHTML = '';
  items.forEach((item, i) => {
    list.innerHTML += `
      <div style="display: flex; gap: 8px; margin-bottom: 8px; flex-wrap: wrap;">
        <input placeholder="Item" value="${item.label}" onchange="updateItem(${i}, 'label', this.value)" />
        <input type="number" placeholder="Cost" value="${item.cost}" onchange="updateItem(${i}, 'cost', this.value)" />
        <select onchange="updateItem(${i}, 'payer', this.value)">
          ${names.map(name => `<option ${name === item.payer ? 'selected' : ''}>${name}</option>`).join('')}
        </select>
        <button onclick="removeItem(${i})">❌</button>
      </div>
    `;
  });
}

function renderUtilization() {
  const table = document.getElementById('utilizationTable');
  table.innerHTML = `
    <div style="overflow-x: auto;">
      <table style="width: 100%; border-collapse: collapse;">
        <thead>
          <tr>
            <th style="border: 1px solid #ddd; padding: 8px; background: #f5f5f5;">Item / Payer</th>
            <th style="border: 1px solid #ddd; padding: 8px; background: #f5f5f5;">Cost</th>
            ${names.map(name => `<th style="border: 1px solid #ddd; padding: 8px; background: #f5f5f5;">${name}</th>`).join('')}
          </tr>
        </thead>
        <tbody>
          ${items.map((item, i) => `
            <tr>
              <td style="border: 1px solid #ddd; padding: 8px;">${item.label} / ${item.payer}</td>
              <td style="border: 1px solid #ddd; padding: 8px;">${item.cost}</td>
              ${names.map((name, j) => `
                <td style="border: 1px solid #ddd; padding: 8px; text-align: center;">
                  <input type="checkbox" ${item.utilized.includes(name) ? 'checked' : ''} onchange="toggleUtilized(${i}, '${name}')" />
                </td>
              `).join('')}
            </tr>
          `).join('')}
        </tbody>
      </table>
    </div>
  `;
}

function toggleUtilized(itemIndex, name) {
  const item = items[itemIndex];
  const index = item.utilized.indexOf(name);
  if (index > -1) {
    item.utilized.splice(index, 1);
  } else {
    item.utilized.push(name);
  }
  saveData();
}

function updateItem(i, field, val) {
  if (field === 'cost') items[i][field] = parseFloat(val) || 0;
  else items[i][field] = val;
  saveData();
}

function removeItem(i) {
  items.splice(i, 1);
  saveData();
  renderItems();
}

function addItem() {
  items.push({ label: 'New Item', cost: 0, payer: names[0], utilized: [...names] });
  saveData();
  renderItems();
}

function showStep(step) {
  for (let i = 1; i <= 4; i++) {
    document.getElementById('step' + i).style.display = i === step ? 'block' : 'none';
  }
  currentStep = step;
}

function nextStep() {
  if (currentStep === 1 && names.length > 0) {
    currentStep = 2;
    showStep(2);
  } else if (currentStep === 2 && items.length > 0) {
    currentStep = 3;
    showStep(3);
    renderUtilization();
  } else if (currentStep === 3 && items.length > 0) {
    currentStep = 4;
    showStep(4);
    calculateResults();
  }
}

function prevStep() {
  if (currentStep > 1) {
    currentStep--;
    showStep(currentStep);
    if (currentStep === 3) renderUtilization();
  }
}

function calculateResults() {
  const results = {};
  names.forEach(n => { results[n] = { paid: 0, owes: 0, net: 0 } });

  items.forEach(item => {
    const utilized = item.utilized || [];
    const share = item.cost / utilized.length;
    results[item.payer].paid += item.cost;
    utilized.forEach(u => {
      results[u].owes += share;
    });
  });

  names.forEach(n => {
    results[n].net = results[n].owes - results[n].paid;
  });

  const resDiv = document.getElementById('results');
  resDiv.innerHTML = '<h3>Balances</h3><table border="1" style="width: 100%; border-collapse: collapse;"><tr><th>Name</th><th>Owes</th><th>Paid</th><th>Net</th></tr>' +
    names.map(n => `<tr><td>${n}</td><td>${results[n].owes.toFixed(2)}</td><td>${results[n].paid.toFixed(2)}</td><td>${results[n].net.toFixed(2)}</td></tr>`).join('') +
    '</table>';
}

function resetCalculator() {
  currentStep = 1;
  showStep(1);
}

window.clearData = clearData;
window.addName = addName;
window.removeName = removeName;
window.addItem = addItem;
window.removeItem = removeItem;
window.nextStep = nextStep;
window.prevStep = prevStep;
window.calculateResults = calculateResults;
window.resetCalculator = resetCalculator;
window.toggleUtilized = toggleUtilized;
