// Words Spelling JS
let wordList = ['apple', 'banana', 'computer', 'elephant'];
let practiceWords = [];
let currentWord = '';
let practiceCount = 0;
let correctCount = 0;
let shuffledLetters = [];
let availableLetters = [];
let userInput = '';

document.addEventListener('DOMContentLoaded', () => {
  loadWordsData();
  updateWordCount();
});

function loadWordsData() {
  const savedData = localStorage.getItem('wordsSpellingData');
  if (savedData) {
    const data = JSON.parse(savedData);
    if (data.words) wordList = data.words;
    practiceCount = data.practiceCount || 0;
    correctCount = data.correctCount || 0;
  }
  document.getElementById('wordText').value = wordList.join('\n');
  updateProgress();
  practiceWords = [...wordList];
}

function saveWordsData() {
  const data = {
    words: wordList,
    practiceCount,
    correctCount
  };
  localStorage.setItem('wordsSpellingData', JSON.stringify(data));
}

function updateWordCount() {
  const text = document.getElementById('wordText').value;
  wordList = text.split('\n').map(w => w.trim()).filter(w => w);
  document.getElementById('wordCount').textContent = `${wordList.length} words`;
  saveWordsData();
}

function clearWordsData() {
  localStorage.removeItem('wordsSpellingData');
  wordList = ['apple', 'banana', 'computer', 'elephant'];
  practiceCount = 0;
  correctCount = 0;
  document.getElementById('wordText').value = wordList.join('\n');
  updateWordCount();
  updateProgress();
}

// Fisher-Yates shuffle
function shuffleLetters(word) {
  const letters = word.split('');
  for (let i = letters.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [letters[i], letters[j]] = [letters[j], letters[i]];
  }
  return letters;
}

function startPractice() {
  if (wordList.length === 0) {
    alert('Add some words first!');
    return;
  }
  practiceWords = [...wordList];
  document.getElementById('wordManagement').style.display = 'none';
  document.getElementById('practiceArea').style.display = 'block';
  nextWord();
}

function nextWord() {
  const randomIndex = Math.floor(Math.random() * practiceWords.length);
  const word = practiceWords.splice(randomIndex, 1)[0];
  if (!word) {
    document.getElementById('feedback').textContent = 'No more words! Back to list or restart.';
    return;
  }
  currentWord = word;
  shuffledLetters = shuffleLetters(currentWord);
  availableLetters = [...shuffledLetters];
  userInput = '';
  document.getElementById('currentWordDisplay').textContent = `Listen to the word: ... (click Play)`;
  updateLettersDisplay();
  updateUserInputDisplay();
  document.getElementById('feedback').textContent = '';
  document.getElementById('autoCheck').style.display = 'none';
  // Auto speak
  setTimeout(() => playWord(), 500);
}

function playWord() {
  speakWord(currentWord);
}

function speakWordSlow(word) {
  speakWordSlowHelper(currentWord);
}

function speakWordSlowHelper(word) {
  const isSentence = word.includes(' ');
  if ('speechSynthesis' in window) {
    if (isSentence) {
      const singleWords = word.split(/\s+/);
      singleWords.forEach((w, index) => {
        setTimeout(() => {
          const utterance = new SpeechSynthesisUtterance(w);
          utterance.lang = 'en-US';
          utterance.rate = 0.3;
          speechSynthesis.speak(utterance);
        }, index * 1000);
      });
    } else {
      const utterance = new SpeechSynthesisUtterance(word);
      utterance.lang = 'en-US';
      utterance.rate = 0.3;
      speechSynthesis.speak(utterance);
    }
  } else {
    alert('Speech synthesis not supported');
  }
}

function speakWord(word) {
  if ('speechSynthesis' in window) {
    const utterance = new SpeechSynthesisUtterance(word);
    utterance.lang = 'en-US';
    utterance.rate = 0.7;
    speechSynthesis.speak(utterance);
  } else {
    alert('Speech synthesis not supported');
  }
}

function updateLettersDisplay() {
  const container = document.getElementById('lettersContainer');
  container.innerHTML = '';
  availableLetters.forEach((letter, index) => {
    const button = document.createElement('button');
    button.textContent = letter;
    button.onclick = () => handleLetterClick(index);
    container.appendChild(button);
  });
}

function handleLetterClick(index) {
  const letter = availableLetters.splice(index, 1)[0];
  userInput += letter;
  updateLettersDisplay();
  updateUserInputDisplay();
  // Auto check if all letters used
  if (availableLetters.length === 0 && userInput.length > 0) {
    document.getElementById('autoCheck').style.display = 'inline-block';
    checkSpelling();
  } else {
    document.getElementById('autoCheck').style.display = 'none';
  }
}

function updateUserInputDisplay() {
  document.getElementById('userInput').textContent = userInput;
}

function checkSpelling() {
  practiceCount++;
  if (userInput.toLowerCase() === currentWord.toLowerCase()) {
    correctCount++;
    document.getElementById('feedback').textContent = '✓ Correct! Well done!';
    document.getElementById('feedback').style.color = 'green';
    updateProgress();
    setTimeout(() => nextWord(), 1500);
  } else {
    document.getElementById('feedback').textContent = `✗ Incorrect. Try again.`;
    document.getElementById('feedback').style.color = 'red';
    setTimeout(clearInput, 1000);
  }
  saveWordsData();
}

function clearInput() {
  userInput = '';
  availableLetters = [...shuffledLetters];
  updateLettersDisplay();
  updateUserInputDisplay();
  document.getElementById('feedback').textContent = '';
  document.getElementById('autoCheck').style.display = 'none';
}

function backToManagement() {
  document.getElementById('practiceArea').style.display = 'none';
  document.getElementById('wordManagement').style.display = 'block';
}

function updateProgress() {
  document.getElementById('progress').textContent = `Practice: ${practiceCount}, Correct: ${correctCount}`;
}

document.getElementById('wordText').addEventListener('input', updateWordCount);

window.clearWordsData = clearWordsData;
window.startPractice = startPractice;
window.playWord = playWord;
window.speakWordSlow = speakWordSlow;
window.nextWord = nextWord;
window.backToManagement = backToManagement;
window.checkSpelling = checkSpelling;
window.clearInput = clearInput;
